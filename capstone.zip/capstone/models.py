from google.cloud import firestore

# Inisialisasi client Firestore
db = firestore.Client()

# Model untuk User
class User:
    def __init__(self, user_id, email, name):
        self.user_id = user_id
        self.email = email
        self.name = name

    def save(self):
        user_ref = db.collection('users').document(self.user_id)
        user_ref.set({
            'email': self.email,
            'name': self.name
        })

    @staticmethod
    def get(user_id):
        user_ref = db.collection('users').document(user_id)
        doc = user_ref.get()
        if doc.exists:
            data = doc.to_dict()
            return User(user_id, data['email'], data['name'])
        return None

# Model untuk HistoryTransaction
class HistoryTransaction:
    def __init__(self, user_id, transaction_id, date, details):
        self.user_id = user_id
        self.transaction_id = transaction_id
        self.date = date
        self.details = details

    def save(self):
        tx_ref = db.collection('history_transactions').document(self.transaction_id)
        tx_ref.set({
            'user_id': self.user_id,
            'date': self.date,
            'details': self.details
        })

    @staticmethod
    def get_all(user_id):
        tx_ref = db.collection('history_transactions')
        transactions = tx_ref.where('user_id', '==', user_id).stream()
        return [HistoryTransaction(doc.id, doc.to_dict()['user_id'], doc.to_dict()['date'], doc.to_dict()['details']) for doc in transactions]
