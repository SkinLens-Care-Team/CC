import os
import json
import time  # Menambahkan impor time
from flask import Flask, render_template, request, redirect, url_for, session
from google.auth.transport.requests import Request
from google_auth_oauthlib.flow import Flow
from models import User, HistoryTransaction

# Inisialisasi Flask
app = Flask(__name__)
app.secret_key = os.environ.get('FLASK_SECRET_KEY', 'your-secret-key')

# ID dan Secret OAuth Google
CLIENT_ID = os.environ.get('CLIENT_ID')
CLIENT_SECRET = os.environ.get('CLIENT_SECRET')
REDIRECT_URI = os.environ.get('REDIRECT_URI')

# OAuth flow untuk login
flow = Flow.from_client_config(
    client_config={
        "web": {
            "client_id": CLIENT_ID,
            "project_id": "capstone-442516",
            "auth_uri": "https://accounts.google.com/o/oauth2/auth",
            "token_uri": "https://oauth2.googleapis.com/token",
            "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
            "client_secret": CLIENT_SECRET,
        }
    },
    scopes=["openid", "email", "profile"],
    redirect_uri=REDIRECT_URI,
)

@app.route('/')
def index():
    if 'credentials' not in session:
        return redirect('login')
    return redirect(url_for('dashboard'))

@app.route('/login')
def login():
    authorization_url, _ = flow.authorization_url(access_type='offline', prompt='consent')
    return redirect(authorization_url)

@app.route('/oauth2callback')
def oauth2callback():
    flow.fetch_token(authorization_response=request.url)
    credentials = flow.credentials
    session['credentials'] = credentials_to_dict(credentials)
    return redirect(url_for('dashboard'))

@app.route('/dashboard')
def dashboard():
    if 'credentials' not in session:
        return redirect('login')

    credentials = session['credentials']
    user_info = get_user_info(credentials)

    # Cek atau simpan data pengguna
    user = User.get(user_info['sub'])
    if not user:
        user = User(user_info['sub'], user_info['email'], user_info['name'])
        user.save()

    # Ambil histori transaksi
    transactions = HistoryTransaction.get_all(user.user_id)

    return render_template('dashboard.html', user=user, transactions=transactions)

@app.route('/transaction', methods=['POST'])
def create_transaction():
    if 'credentials' not in session:
        return redirect('login')

    credentials = session['credentials']
    user_info = get_user_info(credentials)

    # Simulasi transaksi baru
    transaction_id = 'tx-' + str(int(time.time()))
    new_transaction = HistoryTransaction(user_info['sub'], transaction_id, '2024-11-25', 'Pendeteksian kulit berhasil')
    new_transaction.save()

    return redirect(url_for('dashboard'))

def get_user_info(credentials):
    if credentials and credentials.expired and credentials.refresh_token:
        credentials.refresh(Request())
    return json.loads(credentials.id_token)

def credentials_to_dict(credentials):
    return {
        'token': credentials.token,
        'refresh_token': credentials.refresh_token,
        'token_uri': credentials.token_uri,
        'client_id': credentials.client_id,
        'client_secret': credentials.client_secret,
        'scopes': credentials.scopes,
        'id_token': credentials.id_token
    }

if __name__ == '__main__':
    app.run(debug=True)
